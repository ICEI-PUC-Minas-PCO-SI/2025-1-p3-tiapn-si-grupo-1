import React, { useState } from "react";
import { CheckCircle, XCircle } from "lucide-react";
import {
  ModalOverlay,
  ModalBody,
  FormGroup,
  Input,
  Button,
} from "./style";

const DecisionModal = ({ node, onClose, onSave }) => {
  const [options, setOptions] = useState(
    node.data.content?.options || [{ label: "Sim", id: "yes" }, { label: "Não", id: "no" }]
  );
  const [title, setTitle] = useState(node.data.label || "Nova Decisão");

  const handleSave = () => {
    onSave(node.id, { ...node.data, content: { options }, label: title });
    onClose();
  };

  const handleOptionChange = (index, field, value) => {
    const newOptions = [...options];
    newOptions[index][field] = value;
    setOptions(newOptions);
  };

  return (
    <ModalOverlay>
      <ModalBody>
        <FormGroup>
          <Input
            placeholder="Título do Nó"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </FormGroup>
        {options.map((opt, index) => (
          <FormGroup key={opt.id}>
            <Input
              placeholder={`Opção ${index + 1}`}
              value={opt.label}
              onChange={(e) => handleOptionChange(index, "label", e.target.value)}
            />
          </FormGroup>
        ))}
        <div style={{ display: "flex", gap: "8px", marginTop: "16px" }}>
          <Button status="approved" onClick={handleSave}><CheckCircle size={16} /> Salvar</Button>
          <Button status="cancel" onClick={onClose}><XCircle size={16} /> Cancelar</Button>
        </div>
      </ModalBody>
    </ModalOverlay>
  );
};

export default DecisionModal;
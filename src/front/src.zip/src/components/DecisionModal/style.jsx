import styled from "styled-components";

export const ModalOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
  opacity: 0;
  animation: fadeIn 0.3s forwards;

  @keyframes fadeIn {
    to { opacity: 1; }
  }
`;

export const ModalBody = styled.div`
  background: ${props => props.theme.colors.white};
  padding: ${props => props.theme.spacing.lg};
  border-radius: ${props => props.theme.borderRadius.large};
  width: 400px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.md};
  transform: scale(0.95);
  animation: scaleUp 0.3s forwards;

  @keyframes scaleUp {
    to { transform: scale(1); }
  }
`;

export const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.sm};
`;

export const Input = styled.input`
  padding: ${props => props.theme.spacing.sm};
  border: 1px solid ${props => props.theme.colors.border};
  border-radius: ${props => props.theme.borderRadius.small};
  font-size: 14px;
  transition: border-color 0.2s;

  &:focus {
    border-color: ${props => props.theme.colors.primary};
    outline: none;
  }
`;

export const Button = styled.button`
  padding: ${props => props.theme.spacing.sm} ${props => props.theme.spacing.md};
  border: none;
  border-radius: ${props => props.theme.borderRadius.medium};
  background: ${({ status }) => 
    status === "approved" ? props => props.theme.colors.success :
    status === "cancel" ? props => props.theme.colors.error : props => props.theme.colors.primary};
  color: ${props => props.theme.colors.white};
  cursor: pointer;
  font-size: 14px;
  display: flex;
  align-items: center;
  gap: ${props => props.theme.spacing.xs};
  transition: background 0.2s ease, transform 0.1s ease;

  &:hover {
    background: ${({ status }) => 
      status === "approved" ? "#2e7d32" :
      status === "cancel" ? "#d32f2f" : props => props.theme.colors.secondary};
    transform: translateY(-1px);
  }

  &:active {
    transform: translateY(0);
  }
`;
import styled from "styled-components";

export const ModalOverlay = styled.div`
  position: fixed;
  top: 80px; /* Ajusta para começar abaixo do header */
  left: 60px; /* Considera a sidebar do app.jsx */
  right: ${({ $sidebarOpen }) => ($sidebarOpen ? "340px" : "40px")}; /* Ajusta com base no RightSidebar */
  bottom: 0;
  background: ${props => props.theme.colors.background};
  z-index: 100;
  transition: right 0.3s ease; /* Transição suave ao abrir/fechar o RightSidebar */
`;

export const ModalBody = styled.div`
  margin: ${props => props.theme.spacing.md};
  background: ${props => props.theme.colors.white};
  border-radius: ${props => props.theme.borderRadius.large};
  padding: ${props => props.theme.spacing.lg};
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  min-height: calc(100vh - 120px);
  width: 100%;
  max-width: 100%;
  transition: all 0.3s ease;
  overflow: auto;
`;

export const FormGroup = styled.div`
  margin-bottom: ${props => props.theme.spacing.md};
`;

export const Input = styled.input`
  width: 100%;
  padding: ${props => props.theme.spacing.sm};
  border: 1px solid ${props => props.theme.colors.border};
  border-radius: ${props => props.theme.borderRadius.small};
  font-size: 16px;
  transition: border-color 0.2s;

  &:focus {
    border-color: ${props => props.theme.colors.primary};
    outline: none;
  }
`;
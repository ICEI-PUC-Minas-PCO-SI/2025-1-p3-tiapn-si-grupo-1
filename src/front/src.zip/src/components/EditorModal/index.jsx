import React, { useEffect, useRef, useState } from "react";
import EditorJS from "@editorjs/editorjs";
import { ModalOverlay, ModalBody, FormGroup, Input } from "./style";

import HeaderTool from "@editorjs/header";
import List from "@editorjs/list";
import Table from "@editorjs/table";
import ImageTool from "@editorjs/image";

const EditorModal = ({ node, onClose, onSave, showSidebar }) => {
  const editorInstance = useRef(null);
  const holderRef = useRef(null);
  const [isReady, setIsReady] = useState(false);
  const [title, setTitle] = useState(node.data.label || "Novo título");

  useEffect(() => {
    if (!node || !holderRef.current || editorInstance.current) return;

    const initializeEditor = async () => {
      try {
        const dataToLoad = node.data.content?.blocks?.length
          ? node.data.content
          : {
              blocks: [
                {
                  type: "header",
                  data: {
                    text: title,
                    level: 2,
                  },
                },
              ],
            };

        editorInstance.current = new EditorJS({
          holder: holderRef.current,
          autofocus: true,
          data: dataToLoad,
          tools: {
            header: HeaderTool,
            list: List,
            table: Table,
            image: ImageTool,
          },
          onReady: () => {
            setIsReady(true);
          },
        });
      } catch (error) {
        console.error("Failed to initialize editor:", error);
      }
    };

    initializeEditor();

    return () => {
      if (editorInstance.current && typeof editorInstance.current.destroy === "function") {
        editorInstance.current.destroy();
        editorInstance.current = null;
        setIsReady(false);
      }
    };
  }, [node, title]);

  const handleSave = async () => {
    if (!editorInstance.current) {
      onClose();
      return;
    }

    try {
      const content = await editorInstance.current.save();
      onSave(node.id, { ...content, label: title });
    } catch (error) {
      console.error("Error saving content:", error);
    } finally {
      onClose();
    }
  };

  return (
    <ModalOverlay $sidebarOpen={showSidebar}>
      <ModalBody>
        <div
          ref={holderRef}
          key={`editor-${node.id}`}
          style={{ display: isReady ? "block" : "none", minHeight: "300px" }}
        />
        {!isReady && <p>Carregando editor...</p>}
      </ModalBody>
    </ModalOverlay>
  );
};

export default EditorModal;
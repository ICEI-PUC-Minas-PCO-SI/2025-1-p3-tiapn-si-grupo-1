import React, { useState } from "react";
import { Upload, CheckCircle, XCircle } from "lucide-react";
import {
  ModalOverlay,
  ModalBody,
  FormGroup,
  Input,
  Button,
  UploadArea,
  FileItem,
  ProgressBar,
} from "./style";

const MediaModal = ({ node, onClose, onSave }) => {
  const [mediaUrl, setMediaUrl] = useState(node.data.content?.mediaUrl || "");
  const [description, setDescription] = useState(node.data.content?.description || "");
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [title, setTitle] = useState(node.data.label || "Nova Multimídia");

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setUploadedFiles((prev) => [
        ...prev,
        { name: file.name, size: file.size, progress: 50, status: "uploading" },
      ]);
      setTimeout(() => {
        setUploadedFiles((prev) =>
          prev.map((f) =>
            f.name === file.name ? { ...f, progress: 100, status: "completed" } : f
          )
        );
        setMediaUrl(URL.createObjectURL(file));
      }, 2000);
    }
  };

  const handleSave = () => {
    onSave(node.id, { ...node.data, content: { mediaUrl, description }, label: title });
    onClose();
  };

  const removeFile = (name) => {
    setUploadedFiles((prev) => prev.filter((f) => f.name !== name));
    if (mediaUrl.includes(name)) setMediaUrl("");
  };

  return (
    <ModalOverlay>
      <ModalBody>
        <FormGroup>
          <Input
            placeholder="Título do Nó"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </FormGroup>
        <FormGroup>
          <UploadArea>
            <Upload size={24} />
            <span>Escolha um arquivo ou arraste-o aqui.</span>
            <span>JPEG, PNG, PDF, e MP4, até 50 MB.</span>
            <input type="file" accept="image/*,video/*,application/pdf" onChange={handleFileUpload} />
            <Button as="span">Escolher Arquivo</Button>
          </UploadArea>
          {uploadedFiles.map((file) => (
            <FileItem key={file.name}>
              <span>{file.name} <small>{(file.size / 1024).toFixed(2)} KB</small></span>
              <ProgressBar progress={file.progress} />
              {file.status === "completed" ? (
                <button onClick={() => removeFile(file.name)}>🗑️</button>
              ) : (
                <span>{file.status}...</span>
              )}
            </FileItem>
          ))}
          {mediaUrl && <img src={mediaUrl} alt="Preview" style={{ maxWidth: "100%", marginTop: "16px" }} />}
        </FormGroup>
        <FormGroup>
          <Input
            placeholder="Descrição"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </FormGroup>
        <div style={{ display: "flex", gap: "8px", marginTop: "16px" }}>
          <Button status="approved" onClick={handleSave}><CheckCircle size={16} /> Salvar</Button>
          <Button status="cancel" onClick={onClose}><XCircle size={16} /> Cancelar</Button>
        </div>
      </ModalBody>
    </ModalOverlay>
  );
};

export default MediaModal;
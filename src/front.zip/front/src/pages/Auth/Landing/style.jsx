import styled from "styled-components"

export const LandingContainer = styled.section`
  max-height: 530vh;

`
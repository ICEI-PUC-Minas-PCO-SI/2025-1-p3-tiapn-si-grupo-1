import HeaderLogin from "../../../components/LoginComponents/HeaderLogin";
import MainLogin from "../../../components/LoginComponents/MainLogin";


const Login = () => {
  return (  
   <>
    <HeaderLogin/>
    <MainLogin/>
   </>
  );
};

export default Login;

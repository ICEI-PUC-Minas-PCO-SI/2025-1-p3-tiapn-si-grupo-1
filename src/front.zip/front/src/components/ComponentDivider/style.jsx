import styled from "styled-components";

export const Line = styled.hr`
  border: none;
  border-top: 1px solid #ccc;
`;

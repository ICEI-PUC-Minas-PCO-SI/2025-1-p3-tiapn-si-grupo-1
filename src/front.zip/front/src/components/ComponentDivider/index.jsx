import { Line } from "./style";

//Utilizado para dividir componentes
export default function ComponentDivider() {
  return <Line />;
}

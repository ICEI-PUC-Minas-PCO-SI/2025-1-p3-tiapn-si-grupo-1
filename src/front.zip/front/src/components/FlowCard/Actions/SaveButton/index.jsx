import { Button, SaveIcon } from "./style";

export default function SaveButtonComponent() {
  return (
    <Button>
      <SaveIcon></SaveIcon>
    </Button>
  );
}

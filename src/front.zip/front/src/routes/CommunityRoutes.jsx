import React from 'react';
import { Route } from 'react-router-dom';

const CommunityRoutes = () => (
  <>
    <Route path="/comunidade" element={<div style={{padding: "200px"}}> Em breve uma página da comunidade para você! 😊</div>} />
  </>
);

export default CommunityRoutes;
